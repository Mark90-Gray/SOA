#define EXPORT_SYMTAB
#define DEVICE_NAME "miodev"
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/errno.h>
#include <linux/device.h>
#include <linux/kprobes.h>
#include <linux/mutex.h>
#include <linux/mm.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/version.h>
#include <linux/interrupt.h>
#include <linux/time.h>
#include <linux/string.h>
#include <linux/vmalloc.h>
#include <asm/page.h>
#include <asm/cacheflush.h>
#include <asm/apic.h>
#include <linux/syscalls.h>
#include <asm/segment.h>
#include <asm/uaccess.h>
#include <linux/buffer_head.h>
#include <linux/hashtable.h>
#include <linux/types.h> 
#include <linux/rculist.h>
#include "include/configure.h"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Marco Giorgi");
MODULE_DESCRIPTION("progetto SOA");



//stuff for sys call table updating 
#if LINUX_VERSION_CODE > KERNEL_VERSION(3,3,0)
    #include <asm/switch_to.h>
#else
    #include <asm/system.h>
#endif
#ifndef X86_CR0_WP
#define X86_CR0_WP 0x00010000
#endif

#define MAX_FREE 15
#define MAX_SIZE 8192
#define SYS_CALL_INSTALL

//driver
#define MINORS 8
#define OBJECT_MAX_SIZE  (4096)
#define MAX_LINE 60
#define SINGLE_SESSION_OBJECT //just one session per I/O node at a time
//#define SINGLE_INSTANCE

#ifdef SINGLE_INSTANCE
static DEFINE_MUTEX(device_state);
#endif

// Struttura Driver
typedef struct _object_state{
#ifdef SINGLE_SESSION_OBJECT
    struct mutex object_busy;
#endif
    struct mutex operation_synchronizer;
    int valid_bytes;
    char * stream_content;

} object_state;


//HASH TABLE 

DEFINE_HASHTABLE(tbl,9);
EXPORT_SYMBOL(tbl);

//STRUTTURE

//struttura messaggio
typedef struct msg{
	char *mex;
	unsigned msg_len;
	unsigned readers;

} msg;
//struttura thread_data
typedef struct thread_data{
	struct list_head list;
	struct task_struct *t;
	struct msg **msg_ptr_addr;
}thread_data;

//struttura livello
typedef struct tag_lvl{
    int id;
    //size_t size_msg; //posso toglierlo
    int flag;
    
    struct msg *message;
    rwlock_t lock;
    unsigned sleepers; //numero di readers in attesa
    wait_queue_head_t wq;
    struct list_head reader_sleepers; //thread reader in attesa ??? 

}tag_lvl;


//Lista per tag descriptor
typedef struct my_td_list{
     struct list_head list;     //linux kernel list implementation
     int data;
} my_td_list;



//h_node hash table node
typedef struct tag_service{
	int key;
	int tag_descriptor;
	int permission;
	int owner;
	rwlock_t lock;
	struct tag_lvl lvl[MAX_LEVELS];
	//struct flex_array *lvl;
	struct hlist_node node;
}tag_service;

//cerco il tag_service attraverso il tag_descriptor
struct tag_service *search_tag_from_tagdescriptor(int tag){
	
	struct tag_service *cur;
	unsigned bkt;	
	hash_for_each_rcu(tbl, bkt, cur, node){
			if(cur->tag_descriptor == tag){
				
				return cur;
			}
	}	
	return NULL;
}

//cerco il descrittore dalla chiave
int search_tag_from_key(int key,int hash_key,int command){

	struct tag_service *cur;
	int ret =-1;
	switch(command){
		case OPEN:
			hash_for_each_possible_rcu(tbl, cur, node, hash_key) {
				if (cur->key == key) {
					if(cur->permission == ACCESS_PRIVATE_TAG && (int)current->tgid != cur->owner){
						printk("%s: OPEN permission: %d\n", MODNAME, cur->permission);
						return ER_ACCESS;
					}        				
    				ret=cur->tag_descriptor;            				
					break;
				}
			}
			break;
		default: //instance
			hash_for_each_possible_rcu(tbl, cur, node, hash_key) {
				if (cur->key == key){
					printk("%s: INSTANCE tag_service already exists with this key %d\n", MODNAME, cur->key);
					return ER_KEY;
				}
			}
			break;
	}

	return ret;
}