#include "main.h"
#include "./include/vtpmo.h"
#include "./include/sys_call_table_discovery.h"

extern unsigned long *hacked_ni_syscall;
extern unsigned long **hacked_syscall_tbl;
extern unsigned long sys_call_table_address;
extern unsigned long sys_ni_syscall_address;

extern int good_area(unsigned long * addr);
extern int validate_page(unsigned long *addr);
extern void syscall_table_finder(void);
extern struct tag_service *search_tag_from_tagdescriptor(int tag);
extern int search_tag_from_key(int key,int hash_key,int command);

//unsigned long sys_call_table_address = 0x0;
module_param(sys_call_table_address, ulong, 0660);

//unsigned long sys_ni_syscall_address = 0x0;
module_param(sys_ni_syscall_address, ulong, 0660);



int free_entries[MAX_FREE];
module_param_array(free_entries,int,NULL,0660);//default array size already known - here we expose what entries are free

//DRIVER
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 0, 0)
#define get_major(session)	MAJOR(session->f_inode->i_rdev)
#define get_minor(session)	MINOR(session->f_inode->i_rdev)
#else
#define get_major(session)	MAJOR(session->f_dentry->d_inode->i_rdev)
#define get_minor(session)	MINOR(session->f_dentry->d_inode->i_rdev)
#endif

int Major;
object_state objects[MINORS];
spinlock_t driver_spinlock;

LIST_HEAD(Head_Node);

/*  +++++ FUNZIONI +++++ */

// hash function
static int myhash(const int s) {
    int key = 0;
    
    key = s%256;
    return key;
}


//inizializza il singolo livello
void init_single_level(struct tag_lvl *level_ptr, int level_index){
	
	INIT_LIST_HEAD(&(level_ptr->reader_sleepers));	
	level_ptr->id = level_index;
	level_ptr->sleepers = 0;
	level_ptr->flag = 0;
	level_ptr->message=NULL;
	rwlock_init(&level_ptr->lock);	
    init_waitqueue_head(&level_ptr->wq);
}

// inizializza tutti i livelli di un tag service
void init_levels(struct tag_service *tag_service)
{
    int i; 
 	for( i = 0; i < MAX_LEVELS; i++){
        init_single_level(&(tag_service->lvl[i]), i);
    }
}

//init dei tag descriptor
void init_list_tdt(void){
    struct my_td_list *td = NULL;
	struct my_td_list *td2 = NULL;
 	int i;
        
    /*Creating Node*/
    td = kmalloc(sizeof(struct my_td_list), GFP_KERNEL); //kfree nella create tag service
    if (td==NULL){	
		printk("%s: INIT LIST TDT error FIRST kmalloc  \n", MODNAME);	
		return;
	}
    /*Assgin the data that is received*/
    td->data = 0;

    /*Init the list within the struct*/
    INIT_LIST_HEAD(&td->list);

    /*Add Node to Linked List*/
    list_add_tail_rcu(&td->list, &Head_Node);
	//crea 256 nodi tag descriptor
	for(i=1; i<MAX_TAG_SERVICES; i++){
		td2 = kmalloc(sizeof(struct my_td_list), GFP_KERNEL); //kfree nella create tag service
		if (td2==NULL){				
				printk("%s: INIT LIST TDT error kmalloc\n", MODNAME);	
				return ;
		}
		td2->data = i;
		list_add_tail_rcu(&td2->list, &Head_Node);
	}
}

//crea il tag service inizializzando con key, permission, e i 32 livelli 
int create_tag_service(struct tag_service *a, int key, int permission){

	//struct tag_service *cur;
	int tag_desc = -1;
	struct my_td_list *cursor, *temp;
	//unsigned bkt;
	int key_a;
	
	//prendo il primo tag descriptor disponibile qui posso anche non mettere rcu_read perchè è safe
	//list_for_each_entry_safe — iterate over list of given type safe against removal of list entry 
	
	list_for_each_entry_safe(cursor, temp, &Head_Node, list) {
           		tag_desc = cursor->data;
				break;
    }

	a->tag_descriptor = tag_desc;	
	list_del_rcu(&cursor->list);
	synchronize_rcu();
	kfree(cursor); 	//deallocazione tag descriptor
	cursor = NULL;
	//a->owner = current_uid().val;
	a->owner = (int)current->tgid;
	a->key = key;	
	rwlock_init(&a->lock);
	key_a = myhash(key);		
	a->permission = permission;
	printk("%s:Tag descriptor is: %d,  \n", MODNAME,a->tag_descriptor);
	init_levels(a);
	hash_add_rcu(tbl, &(a->node), key_a);
	printk("%s: TAG SERVICE CREATO, tag descriptor: %d, owner: %d, key: %d in key_a: %d, permission: %d \n",MODNAME, a->tag_descriptor,a->owner,a->key, key_a, a->permission);

	return a->tag_descriptor;
}


int control_readers(struct tag_service * c){
	int res = 0;
	int i;
	
	for(i=0; i<MAX_LEVELS; i++){
		if(c->lvl[i].sleepers>0){
			return -1;
		}
	}
	return res;
}


//tag_ctl wake up dei thread sleepers
int wake_up_all_level(struct tag_service *t){

	int i,count=0,readers,flag,cont_temp=0,prev_val;
	struct tag_lvl *l;	
	struct thread_data *cursor, *temp;
	char *wake_up_message = "Mi sono svegliato per colpa della AWAKE_ALL"; //messaggio di default

	for(i=0; i<MAX_LEVELS; i++){
		l = &(t->lvl[i]);
		readers = __atomic_load_n(&l->sleepers, __ATOMIC_SEQ_CST);
		flag = __atomic_load_n(&l->flag, __ATOMIC_SEQ_CST);
		//printk("%s, TAG_CTL AWAKE_ALL readers %d, flag %d\n",MODNAME, readers, flag);
		(l->message)->mex = kzalloc(strlen(wake_up_message),GFP_KERNEL);
		if((l->message)->mex == NULL){
			printk("%s, TAG_CTL AWAKE_ALL error allocation wake_up message\n",MODNAME);
			return ER_ALLOC;
		}
		write_lock(&l->lock);
		if(readers>0){
        	memcpy((char *)(l->message)->mex, (char*) wake_up_message, strlen(wake_up_message));    
		 	
		 	(l->message)->msg_len=(int)strlen((l->message)->mex);
		 	
            __atomic_exchange(&(l->flag), &readers, &prev_val,__ATOMIC_SEQ_CST);
           
            count ++; //solo per il controllo
            wake_up_all(&(l->wq));
           
              
		    list_for_each_entry_safe(cursor, temp, &(l->reader_sleepers), list){
				struct thread_data *p;
				p=cursor;
				list_del_rcu(&p->list);
				cont_temp++; //solo per il controllo
				synchronize_rcu();  
				kfree(p);

			}		
		

		}
		write_unlock(&l->lock);
	}	
    if(count==0){
		printk("%s: TAG_CTL AWAKE ALL there are no readers for this tag_descriptor %d\n", MODNAME, t->tag_descriptor);
        return ER_AWAKE;		
	}
	return 0;
}

/* +++++ DRIVER FUNCTION +++++ */

int dev_open(struct inode *inode, struct file *file) {

    int minor = get_minor(file);
    printk("%s: DRIVER minor %d \n", MODNAME, minor);

    if(minor >= MINORS){
    	printk("%s: DRIVER error minor>=MINORS\n", MODNAME);
        return -ENODEV;
    }

#ifdef SINGLE_INSTANCE
    // this device file is single instance
    if (!mutex_trylock(&device_state)) {
    	printk("%s: DRIVER mutex busy\n",MODNAME);
		return -EBUSY;
    }
#endif

#ifdef SINGLE_SESSION_OBJECT
    if (!mutex_trylock(&(objects[minor].object_busy))) {
    	printk("%s: DRIVER single session error\n",MODNAME);
		goto open_failure;
    }
#endif
    printk("%s: DRIVER device file successfully opened for object with minor %d\n",MODNAME,minor);
    return 0;

#ifdef SINGLE_SESSION_OBJECT
    open_failure:
#ifdef SINGLE_INSTANCE
    mutex_unlock(&device_state);
#endif
    return -EBUSY;
#endif
}

int dev_release(struct inode *inode, struct file *file) {

    int minor = get_minor(file);

#ifdef SINGLE_SESSION_OBJECT
    mutex_unlock(&(objects[minor].object_busy));
#endif

#ifdef SINGLE_INSTANCE
    mutex_unlock(&device_state);
#endif
    printk("%s: device file closed\n",MODNAME);
    return 0;
}


//crea lo snapshoot del sistema da restituire
void status_builder(char * service_status) {
   int j,len =0;
   ssize_t old_size = 0;
   unsigned bkt;
   struct tag_service *cur;
   struct tag_lvl *l;
   char *temp = (char *) vmalloc(sizeof(char) * MAX_LINE);
   if(temp ==NULL){
   		printk("%s: DRIVER error allocating row\n",MODNAME);
   }


   printk("%s, SONO IN STATUS BUILDER\n", MODNAME);
   spin_lock(&driver_spinlock);
   strcpy(service_status, "");
   if(service_status == NULL){
   	   printk("%s: DRIVER error allocating row\n",MODNAME);

   }
   hash_for_each_rcu(tbl, bkt, cur, node){

	    if (cur != NULL){       

            for (j = 0; j < MAX_LEVELS; j++) {
               	l = &(cur->lvl[j]);              
                strcpy(temp, "");
                sprintf(temp,"TAG-key %d TAG-creator %d TAG-level %d Waiting-threads %d\n",cur->key,cur->owner,j,l->sleepers);
                memcpy(service_status+old_size,temp,strlen(temp));
				old_size += strlen(temp);
               }
     	}
   }
   
	len = strlen(service_status);

	//printk("%s, Lunghezza service status %d e old_size = %ld\n",MODNAME,len,old_size);
    if (len == 0) {
      printk("%s: no active service\n", MODNAME);
      spin_unlock(&driver_spinlock);
      return;
    }
    service_status[old_size] = '\0';
    spin_unlock(&driver_spinlock);

}

ssize_t dev_read(struct file *filp, char *buff, size_t len, loff_t *off) {
   int ret,valid_bytes;
   int minor = get_minor(filp);
   object_state *the_object;
   the_object = objects+minor;
   
   printk("%s: DRIVER called read by minor: %d \n", MODNAME,minor);
   
   status_builder(the_object->stream_content);

    valid_bytes = strlen(the_object->stream_content);

 	//printk("%s,Sono dopo valid_bytes %d\n",MODNAME,valid_bytes);
   
   if (*off > valid_bytes) {
        return 0;
   }

   if ((valid_bytes - *off) < len) {
      len = valid_bytes - *off;
   }
     
    ret = copy_to_user(buff,&(the_object->stream_content[*off]),len);

    *off += (len - ret);
    return len - ret;
}

struct file_operations fops = {
        .owner = THIS_MODULE, //permette a tutta l'architettura di lavorare nel driver dopo averlo bloccato
        .read = dev_read,
        .open =  dev_open,
        .release = dev_release
};

int init_driver(void) {

    int i;
    spin_lock_init(&driver_spinlock);
    for(i = 0; i < MINORS; i++){

#ifdef SINGLE_SESSION_OBJECT
        mutex_init(&(objects[i].object_busy));
#endif
        mutex_init(&(objects[i].operation_synchronizer));
        objects[i].valid_bytes = 0;
        objects[i].stream_content = NULL;
        objects[i].stream_content =(char*)vmalloc(sizeof(char)*MAX_SIZE*MAX_LINE);

        if(objects[i].stream_content == NULL) goto revert_allocation;
    }

    Major = __register_chrdev(0, 0, 256, DEVICE_NAME, &fops);

    if (Major < 0) {
        printk("%s: DRIVER registering device failed\n",MODNAME);
        return Major;
    }

    printk("%s: *** DRIVER new device registered, Major = %d ***\n",MODNAME, Major);
    return 0;

    revert_allocation:
    for( ; i >= 0; i--){
        vfree(objects[i].stream_content);
    }
    return -ENOMEM;
}

void cleanup_driver(void) {

    int i;
    for(i = 0; i < MINORS; i++){        
        vfree(objects[i].stream_content);        
    }

    unregister_chrdev(Major, DEVICE_NAME);
    printk("%s: *** DRIVER device unregistered with Major = %d ***\n",MODNAME, Major);
    return;

}

//FINE FUNZIONI DRIVER

#define AUDIT if(1)

/*++++++++++++++++++++++++++++++SYSTEM CALL+++++++++++++++++++++++++*/

//Tag_get
#ifdef SYS_CALL_INSTALL
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,17,0)
__SYSCALL_DEFINEx(3, _tag_get, int, key, int, command, int, permission){
#else
asmlinkage int  sys_tag_get(int key, int command, int permission){
#endif

	struct tag_service *a;
	int key_a,res,empty = -1;
	int suc = -1; //se è 0 vuol dire che non è vuota, 1 altrimenti

	AUDIT{
	//printk("%s: -------------TAG_GET-----------------\n",MODNAME);
	//printk("%s:main tag_get installata correttamente  \n",MODNAME);
	//printk("%s: key %d, command %d, permission %d \n",MODNAME, key, command, permission);
	}
	
	
	switch (command) {
		case OPEN:
			//printk("%s: comando di OPEN ok \n", MODNAME);
			if(key == IPC_PRIVATE_K){
				printk("%s: key is private, cannot open this tag service \n",MODNAME);
				return ER_OPEN;
			}			
			key_a=myhash(key);
			suc = search_tag_from_key(key,key_a,OPEN);
			if(suc == ER_ACCESS) return ER_ACCESS;
			// se torna -1 fallisce perchè non trova il tag descriptor
			if(suc<0){
				//printk("%s: OPEN  tag_service %d not found , ER_INTERNAL = %d\n", MODNAME,key,ER_INTERNAL);
				return ER_INTERNAL;
			}
			break;			
		case INSTANCE:	
			if(key < 0 || key >= MAX_TAG_SERVICES){
				printk("%s: INSTANCE not allowed to create this key %d\n", MODNAME, key);
				return ER_ACCESS;
			}		
			// controllo se già esiste un tag service associato a quella chiave, se torna -1 ha successo.	
			key_a = myhash(key);
			suc = search_tag_from_key(key,key_a,INSTANCE);
			if(suc == ER_KEY) return ER_KEY;			
			empty=list_empty(&Head_Node);			
			if(empty != 0){				
				printk("%s: INSTANCE, key = %d error empty tag_descriptor = %d \n", MODNAME,key,empty);
				return ER_TD;			
			}
			//Allocazione tag service
			a = kmalloc(sizeof(struct tag_service), GFP_KERNEL); // kfree nella remove
			//Gestione errore di kmalloc
			if (a==NULL){				
				printk("%s: INSTANCE error kmalloc with key %d\n", MODNAME,key);	
				return ER_INTERNAL;
			}
			
			//Creo il tag service
			res=create_tag_service(a, key, permission);
			if(res<0){
				printk("%s: INSTANCE error create with key %d\n", MODNAME,key);	
				return ER_CREATE_TAG;
			}		
			suc= a->tag_descriptor;			
			break;
		default:
			printk("%s: inserire un comando valido \n", MODNAME);
			return ER_CMD;
	}
	return suc;
}



//Tag_send
#ifdef SYS_CALL_INSTALL
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,17,0)
__SYSCALL_DEFINEx(4, _tag_send, int, tag, int, level, char*, buffer, size_t, size){
#else
asmlinkage int sys_tag_send(int tag, int level, char* buffer, size_t size){
#endif
	struct tag_service *tag_service;
	struct tag_lvl * tag_level;
	struct msg *mexs;
	struct thread_data *cursor, *temp, *temp2;
	char * addr;
	int ret=0,how_many_readers,flag,prev_val,cont = 0;

	AUDIT{
	//printk("%s: -------------TAG_SEND-----------------\n",MODNAME);
	//printk("%s:main tag_send installata correttamente  \n",MODNAME);
	//printk("%s: tag %d, level %d, messaggio %s, size %ld \n",MODNAME, tag, level, buffer, size);
	}
	
	tag_service = search_tag_from_tagdescriptor(tag);
	if(tag_service==NULL){
		//printk("%s: SEND tag_service %d not found\n",MODNAME,tag);
		return ER_SEARCH_TAG;
	}
	if(tag_service->permission == ACCESS_PRIVATE_TAG && tag_service->owner != (int)current->tgid){
		printk("%s: SEND NOT allowed , PRIVATE ACCESS\n",MODNAME);
		return ER_ACCESS;
	}
	//printk("%s: SEND tag_service trovato\n",MODNAME);
	
	
	rcu_read_lock();
	tag_level = &(tag_service->lvl[level]);
	if(tag_level == NULL){
		rcu_read_unlock();
		return ER_SEARCH_LEVEL;
	} 

	rcu_read_unlock();
	
	addr = kzalloc(MAX_MSG_SIZE,GFP_KERNEL);
    if(addr == NULL){
    	printk("%s: SEND ERROR KMALLOC tag_service = %d\n",MODNAME,tag);
    	return ER_ZALLOC;	
    } 
    ret = copy_from_user((char*)addr,(char*)buffer,size); 
	how_many_readers = __atomic_load_n(&tag_level->sleepers, __ATOMIC_SEQ_CST);
	flag = __atomic_load_n(&tag_level->flag, __ATOMIC_SEQ_CST);

	if(how_many_readers == 0){        
        printk("%s: SEND no readers found for this message, tag_service %d, how_many_readers %d\n", MODNAME,tag,how_many_readers);
        kfree(addr);
        addr=NULL;
        return ER_NO_SLEEPERS;
    }
    else if(flag == 0 && how_many_readers > 0)
    {
    	printk("%s: SEND how_many_readers %d\n", MODNAME,how_many_readers);

    	mexs=tag_level->message;	
		mexs->readers = how_many_readers;
        //mexs->mex = (void*)get_zeroed_page(GFP_KERNEL);
        mexs->mex = kzalloc(MAX_MSG_SIZE,GFP_KERNEL); //deallocata in tag receive
        if(mexs->mex ==NULL){
        	printk("%s: SEND ERROR KMALLOC Message\n", MODNAME);  
        	return ER_ALLOC;
        }
        //usare BUFFER intermedio
        write_lock(&tag_level->lock);
        memcpy((char *)mexs->mex, (char*) addr, strlen(addr));    
        kfree(addr);
		addr=NULL;
        write_unlock(&tag_level->lock);    
        mexs->msg_len = (int) strlen(mexs->mex);        
        __atomic_exchange(&tag_level->flag, &how_many_readers, &prev_val,__ATOMIC_SEQ_CST);
        //printk("%s: SEND dopo atomic_exchange flag = %d , how_many_readers = %d \n", MODNAME,tag_level->flag,how_many_readers);

       // alternativa: wake_up_all(&tag_level->wq);
       // sveglio un singolo thread sleepers alla volta
       list_for_each_entry_safe(cursor, temp, &(tag_level->reader_sleepers), list){
			//printk("%s: SEND awaking sleepers readers,%p \n", MODNAME,cursor);
			wake_up_process(cursor->t);
			//printk("%s: SEND come back from wakeup \n", MODNAME);
		}
      
        how_many_readers = __atomic_load_n(&tag_level->sleepers, __ATOMIC_SEQ_CST);
		flag = __atomic_load_n(&tag_level->flag, __ATOMIC_SEQ_CST);
		//printk("%s: SEND flag =%d , sleepers = %d\n", MODNAME, flag, how_many_readers); //controllo che sia stato tutto svuotato 
       
        list_for_each_entry_safe(cursor, temp, &(tag_level->reader_sleepers), list){
			struct thread_data *p;
			p=cursor;
			//printk("%s, SEND deallocation of threads  %p \n", MODNAME,  p->t);
			list_del_rcu(&p->list);
			synchronize_rcu();
			kfree(p);			
		}       
		//verifica se tutti gli sleeprs sono stati deallocati
		 list_for_each_entry_safe(temp2, temp, &(tag_level->reader_sleepers), list){
			cont ++;
		}     
		//printk("%s: FINE SEND flag =%d , sleepers = %d, cont =%d\n", MODNAME, flag, how_many_readers, cont); 
    }  
	return ret;
}

//Tag_receive
#ifdef SYS_CALL_INSTALL
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,17,0)
__SYSCALL_DEFINEx(4, _tag_receive, int, tag, int, level, char*, buffer, size_t, size){
#else
asmlinkage int sys_tag_receive(int tag, int level, char* buffer, size_t size){
#endif
	struct tag_service *a;
	struct tag_lvl * l;
	struct msg *msg_addr;
	struct thread_data *td;
	char * addr;
	int ok,wait_read,ret=0,how_many_readers,f;
	size_t len;

	AUDIT{
	//printk("%s: -------------TAG_RECEIVE-----------------\n",MODNAME);
	//printk("%s:main tag_receive installata correttamente  \n",MODNAME);
	//printk("%s: tag %d, level %d \n",MODNAME, tag, level);
	}	
	a = search_tag_from_tagdescriptor(tag);
	if(a==NULL){
		//printk("%s,RECEIVE tag_service %d not found\n",MODNAME,tag);
		return ER_SEARCH_TAG;
	}
	
	//printk("%s,RECEIVE owner %d, tag permission = %d, current = %d\n",MODNAME,a->owner,a->permission,(int)current->tgid);
	if(a->permission == ACCESS_PRIVATE_TAG && a->owner != (int)current->tgid){
		printk("%s: RECEIVE NOT allowed , PRIVATE ACCESS\n",MODNAME);
		return ER_ACCESS;
	}
	//printk("%s: RECEIVE ho trovato il tag service \n",MODNAME);	
	ok = read_trylock(&a->lock);
	//printk("%s: RECEIVE il valore ok è %d \n", MODNAME, ok);
	if(!ok){
		printk("%s: RECEIVE lock busy  \n", MODNAME);
		read_unlock(&a->lock);
		return  ER_LOCK;
	}
	
	//prendo il livello 
	l = &(a->lvl[level]);
	if(l == NULL) return ER_SEARCH_LEVEL;

	read_unlock(&a->lock); //TODO: da valutare

	//alloco un thread_data
	td = kmalloc(sizeof(struct thread_data), GFP_KERNEL); // kfree in wakeup all level e in tag_send
	if (td==NULL){				
		printk("%s: RECEIVE error kmalloc thread_data\n", MODNAME);	
		return ER_INTERNAL;
	}
	
	//alloco una struttura messaggio che il writer deve usare per scrivere
	if(l->message==NULL){
		msg_addr=kmalloc(sizeof(struct msg), GFP_KERNEL); // kfree da ultimo sleepers in tag_receive
		if (msg_addr==NULL){				
			printk("%s: RECEIVE error kmalloc msg_addr\n", MODNAME);	
			return ER_INTERNAL;
		}
		l->message=msg_addr;
		td->msg_ptr_addr = &msg_addr;
	}
	//inizializzo thread_desc
	td->msg_ptr_addr= &l->message;
	td->t = current;
	//inizializzo il livello	
	__atomic_fetch_add(&l->sleepers,1,__ATOMIC_SEQ_CST);
	//metto il thread in lista
	list_add_tail_rcu(&td->list, &l->reader_sleepers);
	
	//qui è dove metterò il messaggio letto
	addr = kzalloc(MAX_MSG_SIZE, GFP_KERNEL); //dealloco dopo la copy to user
    if (addr == NULL){
    	printk("%s: RECEIVE error KMALLOC addr\n",MODNAME);
    	return ER_ALLOC;
    } 
    //metto il thread in wait_queue che attende finchè la condizione non si è verificata    
    wait_read = wait_event_interruptible(l->wq, l->flag>0 && l->flag == l->sleepers);

    switch(wait_read){
		case 0:
			printk("%s: RECEIVE LIVELLO %d,sono il thread current %p \n", MODNAME,l->id,current);

    		len = (size_t) (l->message)->msg_len;

    		if(len > size) return ER_BADSIZE;
    		 
    		rcu_read_lock(); //TODO: e se metto read_lock(&l->lock)?   		
    		memcpy(addr,(l->message)->mex,len);    		
			rcu_read_unlock();

			
    		//printk("%s: RECEIVE prima di copy_to_user\n", MODNAME);
    		ret = copy_to_user((char*)buffer,(char*)addr,size);
    		//printk("%s: RECEIVE dopo copy_to_user \n", MODNAME);
    		kfree(addr);
			//printk("%s: RECEIVE dopo kfree\n", MODNAME);
    		addr=NULL;

			how_many_readers = __atomic_load_n(&l->sleepers, __ATOMIC_SEQ_CST);
			f = __atomic_load_n(&l->flag, __ATOMIC_SEQ_CST);

			printk("%s: RECEIVE LIVELLO %d prima del fetch sub :  current %p  l->sleepers = %d, l->flag = %d\n", MODNAME,l->id,current,how_many_readers,f);
			
    		__atomic_fetch_sub(&l->sleepers,1,__ATOMIC_SEQ_CST);
    		__atomic_fetch_sub(&l->flag,1,__ATOMIC_SEQ_CST);

			how_many_readers = __atomic_load_n(&l->sleepers, __ATOMIC_SEQ_CST);
			f = __atomic_load_n(&l->flag, __ATOMIC_SEQ_CST);

			printk("%s: RECEIVE LIVELLO %d dopo del fetch sub :  current %p  l->sleepers = %d, l->flag = %d\n", MODNAME,l->id,current,how_many_readers,f);
			
    		//how_many_readers = __atomic_load_n(&l->sleepers, __ATOMIC_SEQ_CST);
    		
    		if (how_many_readers == 0){
    			
    			//printk("%s: RECEIVE Message deallocating because i am the last reader, sleepers = %d\n",MODNAME, how_many_readers);
    			if(((l->message)->mex) != NULL){
    				//printk("%s: RECEIVE Sono prima della kfree l->message->mex, current = %p \n", MODNAME,current);
    				synchronize_rcu();
    				kfree(l->message->mex);
    				l->message->mex = NULL;
    				//printk("%s: RECEIVE Message deleted \n", MODNAME);
    			}
    			synchronize_rcu();
    			kfree(l->message);
    			l->message=NULL;
    			ret= 0;    		
    			return ret;

    		}
    		ret = 0;
    		break;
    	
    	case -ERESTARTSYS:
    		printk("%s: RECEIVE signal wake up %p\n",MODNAME,current);
    		td->msg_ptr_addr = NULL;
    		kfree(addr);
    		addr = NULL;
    		__atomic_fetch_sub(&l->sleepers,1,__ATOMIC_SEQ_CST);
    		ret = ER_MYSIG;
    		break;
    	
    	default:
    		printk("%s: RECEIVE error in readers waiting queue\n", MODNAME);
    		kfree(addr);
    		addr = NULL;    		
    		__atomic_fetch_sub(&l->sleepers,1,__ATOMIC_SEQ_CST);
    		ret = ER_AWAKE;
    		break;
    }	
   		
	return ret;
}


//Tag_ctl
#ifdef SYS_CALL_INSTALL
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,17,0)
__SYSCALL_DEFINEx(2, _tag_ctl, int, tag, int, command){
#else
asmlinkage int sys_tag_ctl(int tag, int command){
#endif
	struct tag_service *tag_service;
	struct my_td_list *temp;
	struct thread_data *cursor, *temp3;
	int s,i;

	AUDIT{
	//printk("%s: -------------TAG_CTL-----------------\n",MODNAME);
	//printk("%s:main tag_ctl installata correttamente  \n",MODNAME);
	//printk("%s: tag %d, command %d \n",MODNAME, tag, command);
	}
	tag_service=search_tag_from_tagdescriptor(tag);
	if(tag_service==NULL){
		//printk("%s:REMOVE tag_service %d not found\n",MODNAME,tag);
		return ER_SEARCH_TAG;
	}
	if(tag_service->permission == ACCESS_PRIVATE_TAG && tag_service->owner != (int)current->tgid){
		printk("%s: TAG_CTL NOT allowed , PRIVATE ACCESS\n",MODNAME);
		return ER_ACCESS;
	}
	
	switch (command){
		case REMOVE_TAG:			
			//printk("%s: rimozione in corso del tag descriptor:%d\n", MODNAME, tag);
			write_lock(&tag_service->lock);
			if(control_readers(tag_service)<0){
				//printk("%s: REMOVE there are readers in tag_service %d\n", MODNAME, tag);
				write_unlock(&tag_service->lock);
				return ER_RMV;
			}
			// deallocazione dei livelli e messaggio associati al tag service
			for(i=0;i<MAX_LEVELS;i++){
				struct tag_lvl *lvls = &(tag_service->lvl[i]);
				list_for_each_entry_safe(cursor, temp3, &(lvls->reader_sleepers), list){
					struct thread_data *p;
					p=cursor;
					list_del_rcu(&p->list);
					synchronize_rcu();
					kfree(p);
				}			
			}
			
			hlist_del_rcu(&(tag_service->node));
			
			temp = kmalloc(sizeof(struct my_td_list), GFP_KERNEL);
			if (temp == NULL){
				write_unlock(&tag_service->lock);				
				//printk("%s: REMOVE TAG_CTL error kmalloc temp tag_descriptor\n", MODNAME);	
				return ER_INTERNAL;
			}
			
			temp->data = tag;
			list_add_tail_rcu(&temp->list, &Head_Node);
			//printk("%s: ADDED AVAILABLE TAG DESCRIPTOR SUCCESS %d \n",MODNAME,tag);
			write_unlock(&tag_service->lock);
			kfree(tag_service);
			tag_service=NULL;
			//printk("%s: REMOVE SUCCESS %d \n",MODNAME,tag);
			s=0;
			break;
		case AWAKE_ALL_TAG:
			s = wake_up_all_level(tag_service);
			if(s == ER_AWAKE){
				printk("%s: AWAKE_ALL error tag_service %d \n",MODNAME,tag);
				return ER_AWAKE; 
			}
			s=0;
			break;
		default:
			//printk("%s: REMOVE command not valid \n", MODNAME);
			return ER_CMD;
			break;
	}
	return s;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,17,0)
static unsigned long sys_tag_get = (unsigned long) __x64_sys_tag_get;
static unsigned long sys_tag_send = (unsigned long) __x64_sys_tag_send;	
static unsigned long sys_tag_receive = (unsigned long) __x64_sys_tag_receive;	
static unsigned long sys_tag_ctl = (unsigned long) __x64_sys_tag_ctl;	
#else
#endif
#endif
#endif
#endif

unsigned long cr0;

static inline void
write_cr0_forced(unsigned long val)
{
    unsigned long __force_order;

    /* __asm__ __volatile__( */
    asm volatile(
        "mov %0, %%cr0"
        : "+r"(val), "+m"(__force_order));
}

static inline void
protect_memory(void)
{
    write_cr0_forced(cr0);
}

static inline void
unprotect_memory(void)
{
    write_cr0_forced(cr0 & ~X86_CR0_WP);
}

#else
#endif


int init_module(void) {

	//init hash table per i tag_service, list per i tag_descriptor 
	hash_init(tbl);	
	init_list_tdt(); 
  
	printk("%s: ******** initializing ********n",MODNAME);	
	syscall_table_finder();

	if(!hacked_syscall_tbl){
		printk("%s: failed to find the sys_call_table\n",MODNAME);
		return -1;
	}

#ifdef SYS_CALL_INSTALL
	cr0 = read_cr0();
        unprotect_memory();
        hacked_syscall_tbl[FIRST_NI_SYSCALL] = (unsigned long*)sys_tag_get;
        hacked_syscall_tbl[SECOND_NI_SYSCALL] = (unsigned long*)sys_tag_send;
        hacked_syscall_tbl[THIRD_NI_SYSCALL] = (unsigned long*)sys_tag_receive;
        hacked_syscall_tbl[FOURTH_NI_SYSCALL] = (unsigned long*)sys_tag_ctl;
        protect_memory();
	printk("%s: TAG_GET  has been installed on %d\n",MODNAME,FIRST_NI_SYSCALL);
	printk("%s: TAG_SEND has been installed on %d\n",MODNAME,SECOND_NI_SYSCALL);
	printk("%s: TAG_RECEIVE has been installed on %d\n",MODNAME,THIRD_NI_SYSCALL);
	printk("%s: TAG_CTL  has been installed on  %d\n",MODNAME,FOURTH_NI_SYSCALL);	
#else
#endif
    printk("%s: ****** module correctly mounted ******\n",MODNAME);
	init_driver(); //inizializzo anche il driver
	return 0;
}

void cleanup_module(void) {

        unsigned long cr0;

        printk("%s: *** Shutting down Module ***\n",MODNAME);
        cleanup_driver();

#ifdef SYS_CALL_INSTALL
	cr0 = read_cr0();
        unprotect_memory();
        hacked_syscall_tbl[FIRST_NI_SYSCALL] = (unsigned long*)hacked_ni_syscall;
        hacked_syscall_tbl[SECOND_NI_SYSCALL] = (unsigned long*)hacked_ni_syscall;
        hacked_syscall_tbl[THIRD_NI_SYSCALL] = (unsigned long*)hacked_ni_syscall;
        hacked_syscall_tbl[FOURTH_NI_SYSCALL] = (unsigned long*)hacked_ni_syscall;
        protect_memory();
#else
#endif
        printk("%s: *** Module  unmounted *** \n",MODNAME);        
}

