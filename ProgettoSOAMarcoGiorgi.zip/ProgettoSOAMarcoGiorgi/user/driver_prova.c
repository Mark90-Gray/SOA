#include "main_function.h"
#include <sys/ioctl.h>
#include <fcntl.h>

#define sys1 134
#define MAX_SIZE 8192
#define LINE_LENGTH 60
#define REMOVE 178
extern int open_tag(int num, int key);
extern int create_tag(int num, int key, int permission);
extern int send_msg(int num,int tag, int level, char *msg, unsigned int thread_id);
extern int remove_tag(int num, int tag);

int i;
char buff[MAX_SIZE];
#define TAG_TO_CREATE 256



void * the_thread(void* path){
    //printf("sono nel thread\n");
    char* device;
    int fd;
    int ret;
    char mess[MAX_SIZE*LINE_LENGTH];

    device = (char*)path;
   printf("device %s\n", device);
    

    printf("opening device %s\n",device);
    fd = open(device,O_RDWR);
    if(fd == -1) {
        printf("open error on device %s\n",device);
        return NULL;
    }
    printf("device %s successfully opened\n",device);
    //ioctl(fd,1);
    size_t len = MAX_SIZE*LINE_LENGTH;
    //sleep(1);
    printf("********************** threads %ld ******************************\n", pthread_self());
    ret = read(fd,mess,len);

    if (ret < 0)
        fprintf(stdout, "No state to show %s\n", strerror(errno));

    else
        fprintf(stdout, "Current tag service state is \n%s\n", mess);

    close(fd);
    
    return NULL;

}

int main(int argc, char** argv){

   
    int major;
    int minors;
    int ret;
    char *path;
    int i,created_tag=0;
    fflush(stdout);
    if(argc<4){
        printf("useg: prog pathname major minors\n");
        return -1;
    }

    path = argv[1];
    major = strtol(argv[2],NULL,10);
    minors = strtol(argv[3],NULL,10);
    pthread_t tid[minors];

    printf("creating %d minors for device %s with major %d\n",minors,path,major);

    fprintf(stdout, "Starting creating threads... \n");
    for( i = 0; i < TAG_TO_CREATE; i++){
        ret = create_tag(sys1,i, ACCESS_FREE_TAG);
        if(ret == -1) break;
        
        created_tag++;
    }
    
   sleep(1);

    for(i=0;i<minors;i++){
        //creo più nodi
        sprintf(buff,"mknod %s%d c %d %i\n",path,i,major,i);
        system(buff);
        sprintf(buff,"%s%d",path,i);
        printf("buff %s\n", buff);
        pthread_create(&tid[i],NULL,the_thread,strdup(buff));
    }
    for(i=0;i<minors;i++){
        pthread_join(tid[i], NULL);
    }
    for(i=0;i<created_tag;i++){
        ret = remove_tag(REMOVE,i);
        if(ret<0)
            printf("Errore remove  tag = %d \n",i);
    }
    
    sprintf(buff,"rm  %s*\n",path);
    system(buff);
    printf("Exiting...\n");

    return 0;

}

	

	
