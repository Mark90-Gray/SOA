#include "main_function.h"

extern int create_tag(int num, int key, int permission);
extern int recive_msg(int num,int tag, int level, char *msg, unsigned int thread_id);
#define MAX_MSG_SIZE 4096

int ts;
int td;
#define TAG_REMOVE  178 //controllare se corretto il numero 
#define TAG_GET  134
#define TAG_RECEIVE  177

void signal_handler(int sig_num){
	fprintf(stdout, "Reader Process has been stopped , sig num = %d\n",sig_num);
	remove_tag(TAG_REMOVE, ts); 
	exit(EXIT_SUCCESS);
}

int main(int argc, char** argv){
	
	int ret ;
	
	if(argc < 6){
                printf("usage: prog syscall-num tag_get, tag_receive, key, permission, level\n");
                return 0;
        }
        
	char buff[MAX_MSG_SIZE];      
   
	int tag_get_num = strtol(argv[1],NULL,10);
	int tag_receive_num= strtol(argv[2],NULL,10);
	int key = strtol(argv[3], NULL, 10);
	int permission = strtol(argv[4], NULL, 10);
	int lvl = strtol(argv[5], NULL, 10);
	
	signal(SIGTSTP,signal_handler);
	signal(SIGINT,signal_handler);

	td = create_tag(tag_get_num, key, permission);
	if(td < 0) return EXIT_FAILURE;

	sleep(2);
	ts = open_tag(tag_get_num,key);
	if(ts == -1){
		remove_tag(TAG_REMOVE, td);
		return EXIT_FAILURE;
	} 
	

	sleep(1);
	printf("Attendo messaggio\n");	
	ret=receive_msg(tag_receive_num, ts, lvl, buff, (unsigned int) pthread_self());
	if(ret==0)
		printf("RECEIVE this message: %s\n", buff);	
	sleep(1);
	remove_tag(TAG_REMOVE, ts); 
	return 0;
}
	
