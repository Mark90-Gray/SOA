Syscall:
TAG_GET = 134
TAG_RECEIVE = 177
TAG_SEND = 174
TAG_CTL = 178
IPC_PRIVATE = 0
ACCESS_FREE_TAG= 1
ACCESS_PRIVATE_TAG = 0
MAJOR number device = 243 per kernel 4.15/ 240 per kernel 5.4

Se nel montaggio del modulo questi parametri sono diversi, bisogna opportunamente cambiarli in tutti i file user

multi_read_write_level.c: 1 tag service 2+ reader per ognuno dei 32 livello 2+ writer per ognuno dei 32 livelli
multi_read_write_prova.c (opzionale): 1 tag service 1 livello solamente 2+ reader e 2+ writer
diver_prova.c: crea e rimuove directory /dev/miodev*
reader.c: custom tag_get, tag_receive, test con key 8 livello 1, gestione segnale
writer.c: custom tag_get, tag_receive, test con key 8 livello 1, gestione segnale
reader_complete.c: custom tag_get, tag_receive, key, livello e permessi, gestione segnale
remove_tag_service.c: crea  e rimuove tutti e 256 tag service nello stesso file, non rimuove singolarmente.