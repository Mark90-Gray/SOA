#include "main_function.h"



extern int open_tag(int num, int key);
extern int create_tag(int num, int key, int permission);
extern void send_msg(int num,int tag, int level, char *msg, unsigned int thread_id);

char *buff= "Ciao pippo";

int main(int argc, char** argv){
	
	int arg;
	
	if(argc < 2){
                printf("usage: prog syscall-num\n");
                return 0;
        }
        
	char *buff= "Ciao pippo";
        
    // int tag_open_num = strtol(argv[1],NULL,10);
	 //int tag_get_num = strtol(argv[1],NULL,10);
	// int tag_recive_num= strtol(argv[4],NULL,10);
	int tag_ctl_num= strtol(argv[1],NULL,10);
	//int tag_send_num = strtol(argv[3],NULL,10);

	//create_tag(tag_get_num, 8, ACCESS_FREE_TAG);
	/*create_tag(tag_get_num, IPC_PRIVATE_K, ACCESS_PRIVATE_TAG);
	create_tag(tag_get_num, 7, ACCESS_FREE_TAG);
	create_tag(tag_get_num, 5, ACCESS_FREE_TAG);
	create_tag(tag_get_num, 4, ACCESS_FREE_TAG);*/
	//open_tag(tag_open_num, 8);
	//printf("Sono il thread %d \n", (unsigned int) pthread_self());
	//receive_msg(tag_recive_num, 1, 1, buff, (unsigned int) pthread_self());
	//send_msg(tag_send_num, 1,1,"ciao bella", (unsigned int) pthread_self());
	
	//remove_tag(tag_ctl_num, 0);
	wakeup_tag(tag_ctl_num,0);

	//create_tag(tag_get_num, 5, 6); // num syscall, key, permission
	//send_msg(tag_send_num, 5, 5, buff, 2);
	//syscall(tag_recive_num, 6,5,6);
	//syscall(tag_ctl_num, 7,5,6);
	
	
	return 0;
}
	
