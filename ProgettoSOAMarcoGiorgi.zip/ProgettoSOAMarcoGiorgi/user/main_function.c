#include "main_function.h"

int remove_tag(int num, int tag)
{
    int res;
    if(tag < 0 || tag > MAX_TAG_SERVICES-1){
        fprintf(stdout,"Tag descriptor compresi tra 0 e %d\n",MAX_TAG_SERVICES);
        return -1;
    }
    res= syscall(num, tag, REMOVE_TAG);
    switch (res){
        case ER_SEARCH_TAG:
            fprintf(stdout,"Tag service %d non trovato\n",tag);
            break;
        case ER_INTERNAL:
            fprintf(stdout,"Tag service %d errore in kmalloc\n",tag);
            break;
        case 0:
            fprintf(stdout, "Rimozione tag service %d avvenuta con successo\n", tag);
            return 0;
        case ER_RMV:
            fprintf(stdout, "Rimozione fallita tag service %d possiede readers\n", tag);
            break;
       case ER_CMD:
            fprintf(stdout, "Comando non valido per rimuove il tag %d \n", tag);
            break;
        case ER_ACCESS:
            fprintf(stdout,"Tag service %d permesso non consentito\n",tag);
            break;  
        default:
            fprintf(stdout, "Qualcosa è andato storto nella rimozione del tag = %d\n", tag);
            break;

    }
   
    fflush(stdout);
    return -1 ;
}

int send_msg(int num, int tag, int level, char *msg, unsigned int thread_id)
{
    int ret;

    if(tag < 0 || tag > MAX_TAG_SERVICES-1 || level > MAX_LEVELS-1){
        fprintf(stdout,"Tag descriptor < %d e livelli < %d\n",MAX_TAG_SERVICES,MAX_LEVELS);
        return -1;
    }
    ret = syscall(num, tag, level, msg, strlen(msg));
    switch (ret){
        case ER_SEARCH_TAG:
            fprintf(stdout,"SEND:Tag service %d non trovato\n",tag);
            break;
         case ER_ALLOC:
            fprintf(stdout,"SEND:Tag service %d errore Allocazione  MESSAGGIO\n",tag);
            break;
        case ER_SEARCH_LEVEL:
            fprintf(stdout,"SEND:Tag service %d  con livello %d non trovato\n",tag,level);
            break;
        case ER_ZALLOC:
            fprintf(stdout,"SEND:Errore nella kzalloc, tag = %d\n",tag);
            break;
        case ER_NO_SLEEPERS:
            fprintf(stdout,"SEND:non ci sono sleepers in attesa\n");
            break;
        case ER_ACCESS:
            fprintf(stdout,"SEND Tag service %d permesso non consentito\n",tag);
            break;  
        default:
            fprintf(stdout,"SEND:messaggio %s,correttamente consegnato da %u \n",msg,thread_id);
            return 0;
    }
  
    fflush(stdout);
    return -1;
}


int receive_msg(int num, int tag, int level, char *msg, unsigned int thread_id)
{
    int ret;
    if(tag < 0 || tag > MAX_TAG_SERVICES-1 || level > MAX_LEVELS-1){
        fprintf(stdout,"Tag descriptor < %d e livelli < %d\n",MAX_TAG_SERVICES,MAX_LEVELS);
        return -1;
    }
    ret = syscall(num, tag, level, msg, MAX_MSG_SIZE);

    switch(ret){
        case ER_SEARCH_TAG:
            fprintf(stdout,"RECEIVE:Tag service %d non trovato\n",tag);
            break;
        case ER_INTERNAL:
            fprintf(stdout,"RECEIVE:Tag service %d errore in kmalloc\n",tag);
            break;
        case ER_SEARCH_LEVEL:
            fprintf(stdout,"RECEIVE:Tag service %d  con livello %d non trovato\n",tag,level);
            break;
        case ER_BADSIZE:
            fprintf(stdout,"RECEIVE:Tag service %d errore nella size messaggio\n",tag);
            break;
        case ER_LOCK:
            fprintf(stdout,"RECEIVE: read, lock occupato errore\n" );
            break;
        case ER_ALLOC:
            fprintf(stdout,"RECEIVE: read, kzalloc errore\n" );
            break;
        case 0:
            fprintf(stdout,"RECEIVE:read successo %u, messaggio: %s \n", thread_id,msg);
            return 0;
        case ER_MYSIG:
            fprintf(stdout,"RECEIVE:Mi sono svegliato per un segnale %d\n",thread_id);
            break;
        case ER_AWAKE:
            fprintf(stdout,"RECEIVE:Errore nella wait %d\n",thread_id);
            break;
        case ER_ACCESS:
            fprintf(stdout,"RECEIVE Tag service %d permesso non consentito\n",tag);
            break;  
        default:
            fprintf(stdout,"RECEIVE: errore read\n");
            break;
    }

    fflush(stdout);
    return -1 ;
}


int wakeup_tag(int num, int tag)
{
    int res;

    if(tag < 0 || tag > MAX_TAG_SERVICES-1){
        fprintf(stdout,"Tag descriptor compresi tra 0 e %d \n",MAX_TAG_SERVICES);
        return -1;
    }

    res = syscall(num, tag, AWAKE_ALL_TAG);
    switch(res){
        case ER_SEARCH_TAG:
            fprintf(stdout,"WAKE UP: Tag service %d non trovato\n",tag);
            break;
        case ER_AWAKE:
            fprintf(stdout,"WAKE UP:Non ci sono reader da svegliare in questo tag service %d\n", tag);
            break;
        case 0:
            fprintf(stdout,"WAKE UP:Ho svegliato tutti i readers del tag_service %d\n", tag);
            return 0;
        case ER_CMD:
            fprintf(stdout, "WAKE UP:Comando non valido per wakeup dei tag %d \n", tag);
            break;
        case ER_ACCESS:
            fprintf(stdout,"WAKE UP:Tag service %d permesso non consentito\n",tag);
            break;    
        default:
            fprintf(stdout,"WAKE UP:Errore nel wake up all di tutti i readers del tag_service %d\n", tag);
            break;
    }

    fflush(stdout);
    return -1;
}



int open_tag(int num, int key)
{
    int res;
	
    res = syscall(num, key, OPEN);
	
    switch (res){
        case ER_OPEN:
            fprintf(stdout, "Chiave inserita non valida, non posso effettuare accessi per chiave privata\n");
            return -1;
         case ER_ACCESS:
            fprintf(stdout, "Accesso non consentito, il tag_service è impostato ad accesso privato\n");
            return -1;
        case ER_INTERNAL:
            fprintf(stdout, "Accesso fallito, tag_service non trovato\n");
            return -1;
        case ER_CMD:
            fprintf(stdout, "Comando inserito non valido\n");
            return -1;
        default:
            fprintf(stdout, "Open del tag_service %d avvenuta con successo\nTag descriptor: %d \n",key, res);
            break;

    }
    fflush(stdout);
    return res;
}
   


int create_tag(int num, int key, int permission)
{
    
    int res;
    char *perm=" Accesso libero";
    char *priv="";

    if(permission == 500) perm = "Accesso privato";
    if(key == 0) priv= "Chiave privata";
    res = syscall(num, key, INSTANCE, permission);  
	switch (res){
		case ER_INTERNAL:
			fprintf(stdout,"Errore kmalloc  tag descriptor con chiave %d\n",key);
            return -1;
        case ER_ACCESS:
            fprintf(stdout, "Accesso non consentito\n");
            return -1;
		case ER_CMD:
			fprintf(stdout,"Comando non valido, tag descriptor con chiave %d \n",key);
			return -1;	
		case ER_KEY:
            //devo fare una open
			fprintf(stdout,"Chiave %d già esistente \n",key);
            return -2;
		case ER_TD:
			fprintf(stdout,"Tag descriptor con chiave %d momentaneamente non disponibili \n",key);
			return -1;
        case ER_CREATE_TAG:
            fprintf(stdout,"Tag descriptor con chiave %d, errore nella creazione \n",key);
            return -1;  		
		default:
			fprintf(stdout,"Creazione tag_service %d %s avvenuta con successo\nTag_descriptor: %d \nPermesso: %s \n", key, priv, res, perm);
			break;

	}
    fflush(stdout);
    return res;
}
