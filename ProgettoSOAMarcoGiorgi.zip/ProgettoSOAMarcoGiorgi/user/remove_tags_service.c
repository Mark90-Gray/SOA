#include "main_function.h"

//sys call entries
#define TAG_GET 134
#define TAG_SEND 174
#define TAG_RECEIVE 177
#define TAG_CTL 178
//#define REMOVE_ALL 180

extern int remove_tag(int num, int tag);
extern int wakeup_tag(int num, int tag);
extern int open_tag(int num, int key);
extern int create_tag(int num, int key, int permission);
extern int send_msg(int num,int tag, int level, char *msg, unsigned int thread_id);
extern int receive_msg(int num, int tag, int level, char *msg, unsigned int thread_id);


#define NUM_TAG_SERVICE 256

int main(int argc, char** argv){

    int i,ret,created_tag=0;
    int tag_descriptor[NUM_TAG_SERVICE];

    if(argc < 1){
        fprintf(stdout, "No arguments required for %s\n", argv[0]);
        fflush(stdout);
        return EXIT_FAILURE;
    }


    for(i=0;i<NUM_TAG_SERVICE;i++){
        tag_descriptor[i] = create_tag(TAG_GET,i, ACCESS_FREE_TAG); //PROBLEMA se fallisce tag_descriptor[i]== -1/-2 e mi fa errore nella remove gestire bene o fare un file a parte
        if(tag_descriptor[i] == -1) break;
        
        created_tag++;
    }

    sleep(1);
    for(i=0;i<created_tag;i++){
        ret = remove_tag(TAG_CTL,tag_descriptor[i]);
        if(ret <0)
            printf("Errore nella remove del tag_descriptor %d\n",i);
    }    
    printf("Exiting...\n");

    return EXIT_SUCCESS;
}




