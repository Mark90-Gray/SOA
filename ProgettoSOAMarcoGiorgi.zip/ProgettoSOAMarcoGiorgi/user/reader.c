#include "main_function.h"

extern int create_tag(int num, int key, int permission);
extern int receive_msg(int num,int tag, int level, char *msg, unsigned int thread_id);
#define MAX_MSG_SIZE 4096


void signal_handler(int sig_num){
	fprintf(stdout, "Reader Process has been stopped , sig num = %d\n",sig_num);
	exit(EXIT_SUCCESS);
}

int main(int argc, char** argv){
	
	int td;
	int ret;
	if(argc < 2){
                printf("usage: prog syscall-num\n");
                return 0;
        }
        
	char buff[MAX_MSG_SIZE];
        
   
	int tag_get_num = strtol(argv[1],NULL,10);
	int tag_recive_num= strtol(argv[2],NULL,10);
	
	signal(SIGTSTP,signal_handler);
	signal(SIGINT,signal_handler);

	td = create_tag(tag_get_num, 8, ACCESS_FREE_TAG);
	if(td ==-2){
		td = open_tag(tag_get_num,8);
		if(td<0)
			return EXIT_FAILURE;
	}

	sleep(2);
	ret = receive_msg(tag_recive_num, td, 1, buff, (unsigned int) pthread_self());
	if(ret==0)
		printf("RECIVE this message: %s\n", buff);
	
	return 0;
}
	
