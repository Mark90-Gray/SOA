#include "main_function.h"

extern int open_tag(int num, int key);
extern int send_msg(int num,int tag, int level, char *msg, unsigned int thread_id);

void signal_handler(int sig_num){
	fprintf(stdout, "Reader Process has been stopped,sig num =%d\n",sig_num);
	exit(EXIT_SUCCESS);
}

int main(int argc, char** argv){
	
	int td,ret;
	if(argc < 2){
                printf("usage: prog syscall-num\n");
                return 0;
        }
        
        
    int tag_open_num = strtol(argv[1],NULL,10);
	int tag_send_num = strtol(argv[2],NULL,10);


	signal(SIGTSTP,signal_handler);
	signal(SIGINT,signal_handler);
	
	td =open_tag(tag_open_num, 8);
	if(td <0){
		printf("Errore USER nella Open, td = %d \n",td);
		return EXIT_FAILURE;
	}
	printf("Open USER eseguita con successo, td = %d \n",td);

	sleep(2);
	ret=send_msg(tag_send_num, td,1,"Hello world!", (unsigned int) pthread_self());
	if (ret <0)
		printf("Errore send\n");
	return 0;
}
	
