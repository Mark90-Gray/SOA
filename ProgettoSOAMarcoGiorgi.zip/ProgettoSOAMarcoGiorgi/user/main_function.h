#ifndef BASE_FUNCTION_H
#define BASE_FUNCTION_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdbool.h>
#include <signal.h>
#include <unistd.h>
#include <pthread.h>


#include "../include/configure.h"


int remove_tag(int num, int tag);
int wakeup_tag(int num, int tag);
int open_tag(int num, int key);
int create_tag(int num, int key, int permission);
int send_msg(int num,int tag, int level, char *msg, unsigned int thread_id);
int receive_msg(int num, int tag, int level, char *msg, unsigned int thread_id);



#endif
