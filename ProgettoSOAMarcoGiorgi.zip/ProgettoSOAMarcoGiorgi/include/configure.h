//key
#define IPC_PRIVATE_K 0
//command
#define OPEN 0
#define INSTANCE 1
//error
#define ER_OPEN 300
#define ER_CMD  301
#define ER_INTERNAL 302
#define ER_KEY 303
#define ER_TD 304
#define ER_ACCESS 305
#define ER_RMV 306
#define ER_RMV2 307
#define ER_AWAKE 308
#define ER_CREATE_TAG 309
#define ER_SEARCH_TAG 310
#define ER_SEARCH_LEVEL 311
#define ER_BADSIZE 312
#define ER_NO_SLEEPERS 313
#define ER_LOCK 314
#define ER_MYSIG 316
#define ER_ALLOC 317
#define ER_ZALLOC 318

//tag permission
#define ACCESS_PRIVATE_TAG 0
#define ACCESS_FREE_TAG 1

//comand for tag_ctl
#define REMOVE_TAG 0
#define AWAKE_ALL_TAG 1

//other
#define MODNAME "SCTH EXPLOITER"
#define MAX_TAG_SERVICES 256
#define MAX_LEVELS 32
#define MAX_MSG_SIZE 4096

//driver
#define DEVICE_NAME "miodev"




