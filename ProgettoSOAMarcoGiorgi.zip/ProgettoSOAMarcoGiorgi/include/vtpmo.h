
#define NO_MAP (-1)

