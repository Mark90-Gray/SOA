$ make: compila
$ make load: montaggio modulo
$ make unload: smontaggio modulo
$ make clean: pulizia directory